package com.example.projet_mobile.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projet_mobile.R;
import com.example.projet_mobile.adapters.AbonnementAdapter;
import com.example.projet_mobile.database.AppDatabase;
import com.example.projet_mobile.model.Abonnement;

import java.util.List;

public class AbonnementActivity extends AppCompatActivity {

    private ListView listView;
    private Button btnAdd;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abonnement);

        // Liaison des éléments de la vue
        listView = findViewById(R.id.listViewAbonnements);
        btnAdd = findViewById(R.id.btnAjouterAbonnement);

        // Initialiser la base de données
        db = AppDatabase.getInstance(this);

        // Gestion du clic sur le bouton "Ajouter"
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(AbonnementActivity.this, AjouterAbonnementActivity.class);
            startActivity(intent);
        });

        // Charger les abonnements
        loadAbonnements();
    }

    private void loadAbonnements() {
        try {
            List<Abonnement> abonnements = db.abonnementDao().getAll();
            if (abonnements != null && !abonnements.isEmpty()) {
                AbonnementAdapter adapter = new AbonnementAdapter(this, abonnements);
                listView.setAdapter(adapter);
            } else {
                Toast.makeText(this, "Aucun abonnement trouvé.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("AbonnementActivity", "Erreur lors du chargement des abonnements", e);
            Toast.makeText(this, "Erreur de chargement", Toast.LENGTH_SHORT).show();
        }
    }
}
