package com.example.projet_mobile.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projet_mobile.R;

public class MainActivity extends AppCompatActivity {
    Button btnAbonnement, btnBudget, btnPrevision;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAbonnement = findViewById(R.id.btnAbonnement);
        btnBudget = findViewById(R.id.btnBudget);
        btnPrevision = findViewById(R.id.btnPrevision);

        btnAbonnement.setOnClickListener(v -> {
            Toast.makeText(this, "Ouverture Abonnement", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, AbonnementActivity.class));
        });

        btnBudget.setOnClickListener(v -> {
            Toast.makeText(this, "Ouverture Budget", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, BudgetActivity.class));
        });

        btnPrevision.setOnClickListener(v -> {
            Toast.makeText(this, "Ouverture Prévision", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, PrevisionActivity.class));
        });
    }
}
