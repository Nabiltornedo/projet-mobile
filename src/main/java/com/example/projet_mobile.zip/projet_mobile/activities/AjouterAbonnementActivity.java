package com.example.projet_mobile.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projet_mobile.R;
import com.example.projet_mobile.database.AppDatabase;
import com.example.projet_mobile.model.Abonnement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AjouterAbonnementActivity extends AppCompatActivity {
    EditText editNom, editMontant, editDate;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajouter_abonnement);

        editNom = findViewById(R.id.editNom);
        editMontant = findViewById(R.id.editMontant);
        editDate = findViewById(R.id.editDateProchaine);
        btnSave = findViewById(R.id.btnSauvegarderAbonnement);

        btnSave.setOnClickListener(v -> {
            Abonnement a = new Abonnement();
            a.setNom(editNom.getText().toString());
            a.setMontant(Double.parseDouble(editMontant.getText().toString()));
            try {
                a.setDatePaiement(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(editDate.getText().toString()));
            } catch (Exception e) {
                Toast.makeText(this, "Date invalide", Toast.LENGTH_SHORT).show();
                return;
            }

            AppDatabase.getInstance(this).abonnementDao().insert(a);
            Toast.makeText(this, "Abonnement enregistré", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
