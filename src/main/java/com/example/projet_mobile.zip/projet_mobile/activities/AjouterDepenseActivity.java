package com.example.projet_mobile.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projet_mobile.R;
import com.example.projet_mobile.database.AppDatabase;
import com.example.projet_mobile.model.Depense;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class AjouterDepenseActivity extends AppCompatActivity {
    EditText editCategorie, editMontant, editDate;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajouter_depense);

        editCategorie = findViewById(R.id.editCategorie);
        editMontant = findViewById(R.id.editMontant);
        editDate = findViewById(R.id.editDate);
        btnSave = findViewById(R.id.btnAjouterDepense); // ID corrigé ici

        btnSave.setOnClickListener(v -> {
            String categorie = editCategorie.getText().toString().trim();
            String montantStr = editMontant.getText().toString().trim();
            String dateStr = editDate.getText().toString().trim();

            if (categorie.isEmpty() || montantStr.isEmpty() || dateStr.isEmpty()) {
                Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double montant = Double.parseDouble(montantStr);
                Depense d = new Depense();
                d.setCategorie(categorie);
                d.setMontant(montant);
                d.setDate(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(dateStr));

                AppDatabase.getInstance(this).depenseDao().insert(d);
                Toast.makeText(this, "Dépense ajoutée", Toast.LENGTH_SHORT).show();
                finish();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Montant invalide", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Date invalide (format JJ/MM/AAAA)", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
