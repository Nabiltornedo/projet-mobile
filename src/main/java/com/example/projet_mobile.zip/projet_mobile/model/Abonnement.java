package com.example.projet_mobile.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity
public class Abonnement {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nom;
    private double montant;
    private Date datePaiement;
    private String frequence; // exemple: "mensuel", "annuel"

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public double getMontant() { return montant; }
    public void setMontant(double montant) { this.montant = montant; }

    public Date getDatePaiement() { return datePaiement; }
    public void setDatePaiement(Date datePaiement) { this.datePaiement = datePaiement; }

    public String getFrequence() { return frequence; }
    public void setFrequence(String frequence) { this.frequence = frequence; }

    public String getPrix() {
        return "";
    }

    public String getDate() {
        return "";
    }
}
